"""
NumJuggler

Package provides script mcnp.juggler. See its help for description.

"""

from .__version__ import __version__ as version
