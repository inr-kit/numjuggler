# -*- coding: utf-8 -*-

e0 = ""
e1 = " 1 2 3 "
e2 = "1 -- 5"
e3 = "1 -- 3 5 7 -- 9"
e4 = "1 -- "


def get_ranges(s):
    tl = (s + ' 0').split()

    v1 = None
    is_range = False
    for t in tl:
        if t == '--':
            is_range = True
        else:
            if is_range:
                yield v1, int(t)
                v1 = None
                is_range = False
            else:
                if v1 is not None:
                    yield v1, v1
                v1 = int(t)


class Range(object):
    """
    Represents a range or a point. Immutable.
    """
    def __init__(self, n1, n2=None):
        if n2 is None:
            self.__n1 = n1
            self.__n2 = None
        else:
            n1, n2 = sorted((n1, n2))
            self.__n1 = n1
            self.__n2 = n2
        return

    def __contains__(self, value):
        if self.__n2 is None:
            return value == self.__n1
        else:
            return (self.__n1 <= value <= self.__n2)

    def __str__(self):
        if self.n2 is None:
            return str(self.__n1)
        else:
            return '[{} -- {}]'.format(self.__n1, self.__n2)

    def __hash__(self):
        return hash((self.__n1, self.__n2))

    def __eq__(self, o):
        return hash(self) == hash(o)

    def __ne__(self, o):
        return hash(self) != hash(o)

if __name__ == '__main__':
    for e in [e0, e1, e2, e3, e4]:
        print repr(e)
        for r in get_ranges(e):
            print r

    r1 = Range(1)
    r2 = Range(1, 3)
    r3 = Range(4, 2)

    for rng in (r1, r2, r3):
        print rng
        for v in range(5):
            print v, v in rng
