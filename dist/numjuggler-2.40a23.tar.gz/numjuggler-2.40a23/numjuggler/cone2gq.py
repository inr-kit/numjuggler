"""
Generate GQ cards describin cones. For testing nogq2.
"""
from nogq2 import scalar_product, get_cone_or_cyl, areclose


def estr(*args):
    return ' '.join('{:15.8e}'.format(v) for v in args)

def gq(R0, n, t2, typ):
    xn, yn, zn = n
    x0, y0, z0 = R0

    if typ == 'c':
        t21 = 1
        R0n = 0
        r2 = t2
    elif typ == 'k':
        t21 = 1 + t2
        R0n = scalar_product(R0, n)
        r2 = 0
    else:
        raise ValueError('Unknown surface type', typ)

    A = 1 - xn**2*t21
    B = 1 - yn**2*t21
    C = 1 - zn**2*t21

    D = -2*t21*xn*yn
    E = -2*t21*yn*zn
    F = -2*t21*zn*xn

    G = 2*t21*xn*R0n - 2*x0
    H = 2*t21*yn*R0n - 2*y0
    J = 2*t21*zn*R0n - 2*z0

    R02 = scalar_product(R0, R0)
    K = R02 - t21*R0n**2 - r2

    return A, B, C, D, E, F, G, H, J, K


def print_cone(R0, n, t2, typ):
    lines = []
    lines.append('Surface type: {}'.format(typ))
    lines.append('  R0: ' + estr(*R0))
    lines.append('   n: ' + estr(*n))
    lines.append('  t2: ' + estr(t2))
    lines = ['c ' + l for l in lines]
    return lines


def print_gq(sn, pl):
    A, B, C, D, E, F, G, H, J, K = pl
    lines = []
    lines.append('{} GQ '.format(sn))
    lines.append('      ' + estr(A, B, C))
    lines.append('      ' + estr(D, E, F))
    lines.append('      ' + estr(G, H, J, K))
    return lines


def normalize(x, y, z):
    n = (x, y, z)
    l = scalar_product(n, n)**0.5
    return tuple(v/l for v in n)


if __name__ == '__main__':
    R0l = ((0, 0, 0),
           (1, 0, 0),
           (0, 1, 0),
           (0, 0, 1),
           )


    nl = ((1, 0, 0),
          (0, 1, 0),
          (0, 0, 1),
          normalize(1, 1, 0),
          normalize(0, 1, 1),
          normalize(1, 0, 1),
          normalize(1, 1, 1),
          )

    t2l = (0,
           1e-8,
           1e-4,
           0.1,
           1,
           10,
           )

    sn = 1
    for R0 in R0l:
        for n in nl:
            for t2 in t2l:
                for typ in 'ck':
                    pl = gq(R0, n, t2, typ=typ)
                    tp, np, R0p, t2p, r2p, cmnt = get_cone_or_cyl(pl)
                    lines = print_cone(R0, n, t2, typ)
                    linesp = print_cone(R0p, np, t2p, tp)
                    if t2 > 0 and typ != tp:
                        lines.append('wrong typ')
                    for v1, v2 in zip(R0 + n, R0p + np):
                        if not areclose((v1, v2), rtol=1e-8, atol=None):
                            lines.append('wrong R0 or n')
                            break
                    if typ == 'k' and not areclose((t2, t2p), atol=1e-8, rtol=None):
                        lines.append('wrong t2')
                    if typ == 'c' and not areclose((t2, r2p), atol=1e-8, rtol=None):
                        lines.append('wrong r2')
                    if 'wrong' in lines[-1]:
                        lines += linesp
                        lines += print_gq(sn, pl)
                        lines += cmnt
                    sn += 1
                    for l in lines:
                        print l
                    print '='*80
