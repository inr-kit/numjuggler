General info
===============
Numjuggler is a command line tool to handle MCNP input files. Originally its goal was
to renumber cells, surfaces and materials in the MCNP input file, therefore its
name, derived from "Number Juggler". Later more possibilities were added, but the 
orignal name remains.



